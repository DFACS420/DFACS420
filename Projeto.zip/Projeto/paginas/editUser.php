<?php
	include "../basedados/basedados.h";
	session_start();
	
if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION["userType"]==1)
	{
		//se isto for verdade deixa aceder à página
		$username=$_GET['username'];
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  href="personalDataPg.php">Os meus dados pessoais</a>
        <a  class="active" href="userManPg.php">Gerir utilizadores</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Gerir utilizadores</h1>
    <br>
</body>

</html>
<br>

</html>
<?php
		if(isset($_GET['name']) && isset($_GET['username']))
		{
?>
<html>
<!-- Formulário para editar name -->
<h2 ">Alterar Nome</h2>
<br><br>
<form action="" method='POST'>

    <input type='text' name='novoname' placeholder="Novo nome"/>
    <br><br>
    <input type="submit" name="submit" value="Alterar"   />
</form>

</html>
<?php	
			if(isset($_POST['novoname']))
			{
				//tendo os dados preenchidos é necessário atualizar na BD
				$res = "UPDATE users SET name ='".$_POST['novoname']."' WHERE name='".$_GET['name']."'";
				$query = mysqli_query($conn, $res);
				
				if(! $res ){
					die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
				}
			
				echo '<script> alert("name do utilizador alterado com sucesso!")</script>';
				echo '<script>window.location.href = "viewUsersPg.php"</script>'; 
			}
		}
		if (isset($_GET['username']) && empty($_GET['name']) &&empty($_GET['userType']))
		{
?>
<html>
<!-- Formulário para editar name de utilizador -->
<h2 ">Alterar name de utilizador</h2>
<br><br>
<form action='' method='POST'>
    <input type='text' name='novonameUtilizador' placeholder="Novo nome de utilizador"/>
    <br><br>
    <input type='submit' value='Alterar'  >
</form>

</html>
<?php	
			if(isset($_POST['novonameUtilizador']))
			{
				//tendo os dados preenchidos é necessário atualizar na BD
				$res = "UPDATE users SET username='".$_POST['novonameUtilizador']."' WHERE username='".$_GET['username']."'";
				$query = mysqli_query($conn, $res);
				unset($_SESSION['username']); //atualizar a variável de sessão
				$_SESSION['username']=$_POST['novonameUtilizador'];
				
				if(! $res ){
					die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
				}
			
				echo '<script> alert("name de utilizador alterado com sucesso!")</script>';
				echo '<script>window.location.href = "viewUsersPg.php"</script>'; 
			}
		}
		
?>


<?php			
		
		if(isset($_GET['userType']) && isset($_GET['username']))
		{
?>
<html>
<!-- Formulário para editar o tipo de utilizador -->
<h2 ">Alterar tipo de utilizador</h2>
<br><br>
<form action="" method='POST'>
    <label for="novouserType">Tipo de utilizador:</label><br>
    <select name="novouserType">
        <option value='1'>Administrador</option>
        <option value='2'>Professor</option>
    </select>
    <br><br>
    <input type='submit' value='Alterar'   />
</form>

</html>
<?php	
			if(isset($_POST['novouserType']))
			{
				//tendo os dados preenchidos é necessário atualizar na BD
				$res = "UPDATE users SET userType='".$_POST['novouserType']."' WHERE userType='".$_GET['userType']."'";
				$query = mysqli_query($conn, $res);
				
				if(! $res ){
					die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
				}
			
				echo '<script> alert("Tipo do utilizador alterado com sucesso!")</script>';
				echo '<script>window.location.href = "viewUsersPg.php"</script>'; 
			}		
		}	
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
}
?>