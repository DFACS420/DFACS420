<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1 || $_SESSION['userType']==2)
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a href="logout.php">Logout</a>
        <a href="personalDataPg.php">Os meus dados pessoais</a>
        <a href="manQuizz.php">Gerir Quizz</a>
        <a class="active" href="manClasses.php">Gerir Turmas</a>
        <a href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Criar nova Turma</h1>
    <form action='createClass.php' method='GET'>

        <input type='text' name='grade' placeholder="Ano" />
        <br><br>
        <input type='text' name='classLetter' placeholder="Turma" />
        <br><br>
        <br><br>
        <input type='submit' value='Registar' />
    </form>
</body>

</html>
<?php
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>