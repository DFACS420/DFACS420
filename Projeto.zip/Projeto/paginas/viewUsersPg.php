<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1)
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="manClasses.php">Gerir Turmas</a>
        <a  href="manQuizz.php">Gerir Quizz</a>
        <a  class="active" href="userManPg.php">Gerir utilizadores</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Visualização dos Utilizadores</h1>
    <br><br><br>
</body>

</html>
<?php
		$query = "SELECT * FROM users";
		$resultado = mysqli_query($conn, $query);
			
		if(! $resultado ){
			die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
		}
		else 
		{
			//criar uma tabela com a visualização dos utilizadores por validar
			echo "<table border='2' >";
			echo "<tr><th>Nome</th>";
			echo "<th>username</th>";
			echo "<th>Tipo de Utilizador</th></tr>";
			while($row = mysqli_fetch_array($resultado))
			{
				if ($row['username']!=$_SESSION['username']){ //não faz sentido exibir o próprio administrador
					echo "<tr><td>".$row['name']."</td>";
					echo "<td>".$row['username']."</td>";
					
					if ($row['userType']==1)
						echo "<td>Administrador</td>";
					
					else
						echo "<td>Professor</td>";
					
					echo "<td><a href='deleteUser.php?username=".$row['username']."'><input type=button value='Eliminar' ></a></td>";
					echo "<td><a href='editUser.php?username=".$row['username']."&userType=".$row['userType']."'><input type=button value='Editar'></a></td></tr>";
				}
			}
			echo "</table><br><br>";
		}
	}
	else 
	{
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>