<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1 || $_SESSION['userType']==2)
	{
		$name=$_GET['name'];
?>
<html>
<head>
	<link rel="stylesheet" href="head.css">
	</head>
	<body>
		<div class="topnav">
			<a style="float:left" href="index.php">Framework</a>
			<a  href="logout.php">Logout</a>
			<a  href="personalDataPg.php">Os meus dados pessoais</a>
			<a  href="editDataPg.php">Gerir marcações</a>
			<a  class="active" href="userManPg.php">Gerir users</a>
			<a  href="userIndex.php">Início</a>
		</div>
		<br>
</html>
<?php
	echo "<h1>Apagar utilizador: ".$name."</h1>";
?>
<html>	
		<br>
		<form action="" method='POST'>
			<label for="opcao">Tem a certeza que quer apagar este utilizador?</label><br>
			<input type="radio" name="opcao" value="sim">Sim
			<input type="radio" name="opcao" value="nao">Não
			<br><br>
			<input type='submit' value='Confirmar'  />
		</form>	
	</body>
</html>
<?php		
		if (isset($_POST['opcao']))
		{
			$opcao=$_POST['opcao'];
			if ($opcao=="sim")
			{
				$query = "DELETE FROM students WHERE name='".$name."' ";
				$resultado = mysqli_query($conn, $query);
				
				echo '<script> alert("O utilizador foi apagado com sucesso!")</script>';
				echo '<script>window.location.href = "verAluno.php"</script>';
			}
			else 
			{
				echo '<script> alert("O utilizador não foi apagado!")</script>';
				echo '<script>window.location.href = "verAluno.php"</script>';
			}
		}
	}	
	else 
	{
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}	
?>
