<?php
	ob_start();
	
	//incluir o ficheiro que coneta com a bd
	require "../basedados/basedados.h";
	
	

	if (isset($_GET['username']) && isset($_GET['password']))
	{
		session_start();

		$username = $_GET['username'];
		$password = $_GET['password'];
		$password = md5($password);
		$res = "SELECT * FROM users WHERE username='".$username."' AND password='".$password."'";
		
		
		$query=mysqli_query($conn,$res);
		
		if (mysqli_num_rows($query) == 1){
			$row = mysqli_fetch_array($query);
			if($row == FALSE) { 
				die(mysql_error());	
			}
			
			switch ($row["userType"])
			{
				case 1:
					$_SESSION["login"] = TRUE;
					$_SESSION["username"] = $username;
					$_SESSION["password"] = $password;
					$_SESSION["userType"] = 1;
					header("Location:userIndex.php");
					break;
					
				case 2:
					$_SESSION["login"] = TRUE;
					$_SESSION["username"] = $username;
					$_SESSION["password"] = $password;
					$_SESSION["userType"] = 2;
					header("Location:userIndex.php");
					break;
				
					
				default:
					echo '<script> alert("Tipo de utilizador não permitido!")</script>';
					echo '<script>window.location.href = "loginPg.php"</script>';	
			}
		}
	}
	else 
	{
		echo '<script> alert("Dados inválidos! Por favor, tente de novo.")</script>';
		echo '<script>window.location.href = "loginPg.php"</script>';	
	}
?>