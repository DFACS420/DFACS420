<html>
<!--Este é o código html da barra de navegação -->

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
    <a style="float:left" href="index.php">Framework</a>
        <a href="registerPg.php">Registo</a>
        <a class="active" href="loginPg.php">Login</a>
        <a href="index.php">Início</a>
    </div>


<!--Formulário de login-->
<h1>Página de Login</h1>
<br>
<form action='login.php' method='GET'>

    <input type='text' name='username' placeholder="Username"/>
    <br><br>
    <input type='password' name='password' placeholder="Password" />
    <br><br>
    <input type='submit' value='Login' />
    
</form>

</body>
</html>