<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==2)
	{
		$name = $_GET['name'];
		$class = $_GET['class'];
		
		//verificar se algum dos campos do formulário está vazio
		//se sim, apresenta erro
		if (empty($name) || empty($class))
		{
			echo '<script>alert("ERRO no registo! Verifique os dados inseridos!")</script>'; //cria um alerta popup
			echo '<script>window.location.href = "manClasses.php"</script>'; //volta à página de registo
		}
		else 
		{
			
			$query = "INSERT INTO students VALUES ('".$id."', '".$name."','".$class."')";
			$resultado = mysqli_query($conn, $query);
			
			echo '<script> alert("Novo utilizador registado com sucesso!")</script>';
			echo '<script>window.location.href = "manClasses.php"</script>';
            
		}
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script>alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>