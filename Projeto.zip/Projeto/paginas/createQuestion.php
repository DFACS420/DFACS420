<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1 || $_SESSION['userType']==2)
	{
		$subject = $_GET['subject'];
		$type = $_GET['type'];
		$question = $_GET['question'];
		$answer = $_GET['answer'];
        $correct = $_GET['correct'];
		
		//verificar se algum dos campos do formulário está vazio
		//se sim, apresenta erro
		if (empty($question) || empty($answer))
		{
			echo '<script>alert("ERRO no registo! Verifique os dados inseridos!")</script>'; //cria um alerta popup
			echo '<script>window.location.href = "createQuestionPg.php"</script>'; //volta à página de registo
		}
		else
		{
			//verificar se o utilizador já existe
			$res = "SELECT question FROM questions WHERE question='".$question."'";
			$verificaUtilizador = mysqli_query($conn, $res);
			$utilizadorExiste = mysqli_num_rows($verificaUtilizador);
		
			if ($utilizadorExiste)
			{
				echo '<script> alert("Esta pergunta já existe! Altere a pergunta.")</script>';
				echo '<script>window.location.href = "createQuestionPg.php"</script>';
			}
			else 
			{
				
				$query = "INSERT INTO questions VALUES ('".$id."','".$subject."','".$type."','".$question."')";
                $query = "INSERT INTO answers VALUES ('".$id."','".$answer."','".$correct."')";
				$resultado = mysqli_query($conn, $query);
		
				echo '<script> alert("Pergunta registada com sucesso!")</script>';
				echo '<script>window.location.href = "manQuizz.php"</script>';
			}
		}
	}
	else
	{
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>