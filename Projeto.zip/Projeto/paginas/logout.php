<?php
	include "../basedados/basedados.h";
	
	session_start();
	
	if ($_SESSION["login"]){
		session_destroy();
		echo '<script> alert("Obrigado pela sua preferência! Até à próxima!"); </script>';
		echo '<script>window.location.href = "index.php"</script>';
		
	}else{
		echo '<script> alert("Erro! Não existe sessão iniciada!"); </script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>