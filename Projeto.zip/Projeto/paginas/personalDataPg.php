<?php
	//é necessário proteger os dados de terceiros
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]))
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

</html>
<?php
	if ($_SESSION['userType']==1)
	{
		//aqui inclui-se a barra de navegação do Administrador
?>
<html>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  class="active" href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="manClasses.php">Gerir Turmas</a>
        <a  href="manQuizz.php">Gerir Quizz</a>
        <a  href="userManPg.php">Gerir utilizadores</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Os meus dados pessoais</h1>
    <br><br>
</body>

</html>
<?php
	}
	if ($_SESSION['userType']==2)
	{
		//aqui inclui-se a barra de navegação do Inspector
?>
<html>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  class="active" href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="manQuizz.php">Gerir Quizz</a>
        <a  href="manClasses.php">Gerir Turmas</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Os meus dados pessoais</h1>
    <br><br>
</body>

</html>
<?php
	}
?>

</html>
<?php
	
	$query = "SELECT * FROM users WHERE username = '".$_SESSION['username']."'";
	$resultado = mysqli_query($conn, $query);
		
	if(! $resultado ){
		die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
	}
		
	//criar uma tabela com a visualização dos dados pessoais
	echo "<table>";
	while($row = mysqli_fetch_array($resultado))
	{

	echo "<tr>
	<th>Nome</th>
	<td>".$row['name']."</td>
	<td><a href='chData.php?name=".$row['name']."'> <input type=button value='Alterar'></a></td>
	</tr>";
	
	echo "<tr>
	<th>Username</th>
	<td>".$row['username']."</td>
	<td><a href='chData.php?username=".$row['username']."'><input type=button value='Alterar'></a></td>
	</tr>";

	echo "</table><br><br>";
	}
?>
<html>
<br>
<a href="chPasswordPg.php" /> <input type=button value='Alterar Password'></a>

</html>
<?php		
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>