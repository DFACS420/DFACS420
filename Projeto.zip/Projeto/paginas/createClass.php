<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) &&  $_SESSION['userType']==2 || $_SESSION['userType']==1)
	{
		$grade = $_GET['grade'];
		$classLetter = $_GET['classLetter'];
		
		//verificar se algum dos campos do formulário está vazio
		//se sim, apresenta erro
		if (empty($grade) || empty($classLetter))
		{
			echo '<script>alert("ERRO no registo! Verifique os dados inseridos!")</script>'; //cria um alerta popup
			echo '<script>window.location.href = "createClass.php"</script>'; //volta à página de registo
		}
		else
		{
			//verificar se a turma já existe
			$res = "SELECT grade, classLetter FROM classes WHERE grade='".$grade."' AND classLetter = '".$classLetter."'";
			$verificaUtilizador = mysqli_query($conn, $res);
			$utilizadorExiste = mysqli_num_rows($verificaUtilizador);
		
			if ($utilizadorExiste)
			{
				echo '<script> alert("Este utilizador já existe! Altere o name de utilizador ou email.")</script>';
				echo '<script>window.location.href = "createClass.php"</script>';
			}
			else 
			{
				$query = "INSERT INTO classes VALUES ('".$id."', '".$grade."','".$classLetter."')";
				$resultado = mysqli_query($conn, $query);
		
				echo '<script> alert("Nova turma registada com sucesso!")</script>';
				echo '<script>window.location.href = "manClasses.php"</script>';
			}
		}
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>