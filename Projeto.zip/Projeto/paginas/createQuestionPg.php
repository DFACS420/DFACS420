<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1 || $_SESSION['userType']==2)
	{
		//se isto for verdade deixa aceder à página
       
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a href="logout.php">Logout</a>
        <a href="personalDataPg.php">Os meus dados pessoais</a>
        <a class="active" href="manQuizz.php">Gerir Quizz</a>
        <a href="manClasses.php">Gerir Turmas</a>
        <a href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Criar nova Pergunta</h1>
    <form action='createQuestion.php' method='GET'>
        <label style="font-size: x-large;" for="type">Tipo de Pergunta:</label><br><br>
        <select name="type">
            <option disabled selected>Escolha o tipo de pergunta</option>
            <option value='1'>Verdadeiro/Falso</option>
            <option value='2'>Escolha Multipla</option>
            <option value='3'>Resposta Multipla</option>
            <option value='4'>Associação</option>
        </select>
        <br><br>
        <label style="font-size: x-large;" for="type">Disciplina:</label><br><br>
        <select name="type">
            <option disabled selected>Escolha uma Disciplina</option>

            <?php
                    $res = mysqli_query($conn, "SELECT category FROM categories");
                    while($data=mysqli_fetch_array($res)){
                        
                        echo "<option value='". $data['subject'] ."'>" .$data['subject'] ."</option>";
                    }
            ?>

        </select>
        <br><br>
        <input type='text' name='question' placeholder="Pergunta" />
        <br><br>

        <input type="text" name="answer[0][text]" placeholder="Resposta 1">
        <input type="checkbox" name="answer[0][correct]" value=1>

        <br><br>
        <input type="text" name="answer[1][text]" placeholder="Resposta 2">
        <input type="checkbox" name="answer[1][correct]" value=1>

        <br><br>
        <input type="text" name="answer[2][text]" placeholder="Resposta 3">
        <input type="checkbox" name="answer[2][correct]" value=1>

        <br><br>
        <input type="text" name="answer[3][text]" placeholder="Resposta 4">
        <input type="checkbox" name="answer[3][correct]" value=1>

        <br><br>
        <br><br>

        <input type='submit' value='Registar' />
    </form>
</body>

</html>
<?php
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>