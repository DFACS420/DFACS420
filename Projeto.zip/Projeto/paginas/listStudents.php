<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1 || $_SESSION['userType']==2)
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="manQuizz.php">Gerir Quizz</a>
        <a  class="active" href="manClasses.php">Gerir Turmas</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Visualização dos Utilizadores</h1>
    <br><br><br>
</body>

</html>
<?php
		$query = "SELECT * FROM students";
		$resultado = mysqli_query($conn, $query);
			
		if(! $resultado ){
			die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
		}
		else 
		{
			//criar uma tabela com a visualização dos utilizadores por validar
			echo "<table>";
			echo "<tr><th>Nome</th>";
			echo "<th>ID Turma</th>";

			while($row = mysqli_fetch_array($resultado))
			{
				echo "<tr><td>".$row['name']."</td>";
				echo "<td>".$row['class']."</td>";
					
				echo "<td><a href='eliminarAluno.php?name=".$row['name']."'><input type=button value='Eliminar''></a></td>";
				echo "<td><a href='editUser.php?name=".$row['name']."&class=".$row['class']."'><input type=button value='Editar''></a></td></tr>";
				
			}
			echo "</table><br><br>";
		}
	}
	else 
	{
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>