<?php
	include "../basedados/basedados.h";
	session_start();
	
if($_SESSION["login"] && isset($_SESSION["userType"]))
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

</html>
<?php
		if ($_SESSION['userType']==1)
		{
			//aqui inclui-se a barra de navegação do Administrador
?>
<html>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  class="active" href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="userManPg.php">Gerir utilizadores</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Os meus dados pessoais</h1>
    <br>
</body>

</html>
<?php
		}
		if ($_SESSION['userType']==2)
		{
			//aqui inclui-se a barra de navegação do Inspector
?>
<html>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  class="active" href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="manQuizzz.php">Gerir Quizz</a>
        <a  href="manClasses.php">Gerir Turmas</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Os meus dados pessoais</h1>
    <br>
</body>

</html>
<?php
		}
		
?>
<html>

<?php
		if(!empty($_GET['name']))
		{
?>
<html>
<!-- Formulário para editar name -->
<h2 ">Alterar name</h2>
<br><br>
<form action="" method='POST'>
    <input type='text' name='novoname' placeholder="Novo nome"/>
    <br><br>
    <input type="submit" name="submit" value="Alterar"   />
</form>

</html>
<?php	
			if(isset($_POST['novoname']))
			{
				//tendo os dados preenchidos é necessário atualizar na BD
				$res = "UPDATE users SET name='".$_POST['novoname']."' WHERE username='".$_SESSION['username']."'";
				$query = mysqli_query($conn, $res);
				
				if(! $res ){
					die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
				}
			
				echo '<script> alert("name alterado com sucesso!")</script>';
				echo '<script>window.location.href = "personalDataPg.php"</script>'; 
			}
		}
		if (isset($_GET['username']))
		{
?>
<html>
<!-- Formulário para editar name de utilizador -->
<h2 ">Alterar name de utilizador</h2>
<br><br>
<form action='' method='POST'>
    
    <input type='text' name='novonameUtilizador' placeholder="Username"/>
    <br><br>
    <input type='submit' value='Alterar'  >
</form>

</html>
<?php	
			if(isset($_POST['novonameUtilizador']))
			{
				//tendo os dados preenchidos é necessário atualizar na BD
				$res = "UPDATE users SET username='".$_POST['novonameUtilizador']."' WHERE username='".$_SESSION['username']."'";
				$query = mysqli_query($conn, $res);
				unset($_SESSION['username']); //atualizar a variável de sessão
				$_SESSION['username']=$_POST['novonameUtilizador'];
				
				if(! $res ){
					die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
				}
			
				echo '<script> alert("name de utilizador alterado com sucesso!")</script>';
				echo '<script>window.location.href = "personalDataPg.php"</script>'; 
			}
		}
	
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}

?>