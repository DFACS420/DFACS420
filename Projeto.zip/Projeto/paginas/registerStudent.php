<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==2)
	{
		$username = $_GET['username'];
		$password = $_GET['password'];
		$userType = $_GET['userType'];
		$name = $_GET['name'];
		
		//verificar se algum dos campos do formulário está vazio
		//se sim, apresenta erro
		if (empty($name) ||empty($class) )
		{
			echo '<script>alert("ERRO no registo! Verifique os dados inseridos!")</script>'; //cria um alerta popup
			echo '<script>window.location.href = "paginaCriacaoAluno.php"</script>'; //volta à página de registo
		}
		else 
		{
			//verificar se o utilizador já existe
			$res = "SELECT username FROM utilizadores WHERE username='".$username."'";
			$verificaUtilizador = mysqli_query($conn, $res);
			$utilizadorExiste = mysqli_num_rows($verificaUtilizador);
		
			if ($utilizadorExiste)
			{
				echo '<script> alert("Este utilizador já existe! Altere o name de utilizador ou email.")</script>';
				echo '<script>window.location.href = "paginaCriacaoAluno.php"</script>';
			}
			else 
			{
				$password = md5($password);
				$query = "INSERT INTO utilizadores VALUES ('".$username."','".$password."','".$userType."','".$name."','".$morada."','".$contacto."','".$email."')";
				$resultado = mysqli_query($conn, $query);
		
				echo '<script> alert("Novo utilizador registado com sucesso!")</script>';
				echo '<script>window.location.href = "manClasses.php"</script>';
			}
		}
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>