<?php 
	//é necessário proteger os dados de terceiros, isto é, só tem acesso o tipo de utilizador correto
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"])){
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

</html>
<?php
	if ($_SESSION['userType']==1)
	{
		//aqui inclui-se a barra de navegação do Administrador
?>
<html>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a href="logout.php">Logout</a>
        <a href="personalDataPg.php">Os meus dados pessoais</a>
        <a href="manClasses.php">Gerir Turmas</a>
        <a class="active" href="manQuizz.php">Gerir Quizz</a>
        <a href="userManPg.php">Gerir utilizadores</a>
        <a href="userIndex.php">Início</a>
    </div>
    <h1>Framework</h1>
    <form action='createSubject.php' method='GET'>
    <input type='text' name='subject' placeholder="Disciplina" />
    <br><br>
    <input type='submit' value='Adicionar'/>
    </form>
</body>



</html>
<?php
	}
	if ($_SESSION['userType']==2)
	{
		//aqui inclui-se a barra de navegação do Professor
?>
<html>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a href="logout.php">Logout</a>
        <a href="personalDataPg.php">Os meus dados pessoais</a>
        <a class="active" href="manQuizz.php">Gerir Quizz</a>
        <a href="manClasses.php">Gerir Turmas</a>
        <a href="userIndex.php">Início</a>
    </div>
    <h1>Framework</h1>

    <form action='createSubject.php' method='GET'>
    <input type='text' name='subject' placeholder="Disciplina" />
    <br><br>
    <input type='submit' value='Adicionar'/>
    </form>
</body>

</html>
<?php   
	}
    }
    else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>