<?php
	//é necessário proteger os dados de terceiros
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && ($_SESSION['userType'])==1 || ($_SESSION['userType']==2))
	{
		$passwordAtual = $_GET['passwordAtual'];
		$passwordAtual = md5($passwordAtual);
		
		$novaPassword = $_GET['novaPassword'];
		$novaPassword = md5($novaPassword);
		
		$confirmacaoPassword = $_GET['confirmacaoPassword'];
		$confirmacaoPassword = md5($confirmacaoPassword);
		
		if ($passwordAtual != $_SESSION['password'])
		{ 	
		//se a pass atual não for a correta
			echo '<script> alert("A Password atual inserida não está correta!")</script>';
			echo '<script>window.location.href = "chPasswordPg.php"</script>';
		}
		else if ($novaPassword != $confirmacaoPassword)
		{
			echo '<script> alert("A nova password não foi confirmada corretamente!")</script>';
			echo '<script>window.location.href = "chPasswordPg.php"</script>';
		} 
		else 
		{
			//aqui os dados estão corretos e a password pode ser alterada
			
			$query = "UPDATE users SET password='".$novaPassword."' WHERE username='".$_SESSION['username']."' AND password='".$_SESSION['password']. "'";
			$resultado = mysqli_query($conn, $query);
		
			if(! $resultado )
			{
				die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
			}
		
			echo '<script> alert("A sua password foi alterada com sucesso! \n Por favor, faça login de novo.")</script>';
			echo '<script>window.location.href = "loginPg.php"</script>'; //para atualizar a variável de sessão
		}
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}

?>