<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><!-- poem os acentos no site -->
<!--Código html da barra de navegação, etc.-->

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a href="registerPg.php">Registo</a>
        <a href="LoginPg.php">Login</a>
        <a class="active" href="index.php">Início</a>
    </div>
    <h1>Framework</h1>


</body>

</html>