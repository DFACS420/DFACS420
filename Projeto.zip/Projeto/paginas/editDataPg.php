<?php
	//é necessário proteger os dados de terceiros
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION["userType"]==3)
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  class="active" href="editDataPg.php">Os meus dados pessoais</a>
        <a  href="">As minhas marcações</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <h1>Dados Pessoais</h1>
</body>

</html>
<?php
		$query = "SELECT * FROM utilizadores WHERE nameUtilizador = '".$_SESSION['nameUtilizador']."'";
		$resultado = mysqli_query($conn, $query);
		
		if(! $resultado ){
			die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
		}
		
		//criar uma tabela com a visualização dos dados pessoais
		echo "<table border='1' style='; text-align:left; margin-left: auto; margin-right:auto; font-size: 20px'>";
		while($row = mysqli_fetch_array($resultado))
		{
			echo "<tr><td>name</td><td>".$row['name']."</td></tr>";
			echo "<tr><td>name de utilizador</td><td>".$row['nameUtilizador']."</td></tr>";
			echo "<tr><td>Morada</td><td>".$row['morada']."</td></tr>";
			echo "<tr><td>Contacto</td><td>".$row['contacto']."</td></tr>";
			echo "<tr><td>Email</td><td>".$row['email']."</td></tr>";
			echo "</table><br><br>";
		}
?>
<html>
<a href="chData.php" /> <input type=button value='Editar dados pessoais'></a>
<br><br>
<a href="chPassword.php" /> <input type=button value='Alterar a minha password '></a>

</html>
<?php		
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar na página de Cliente!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>