<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1)
	{
		//se isto for verdade deixa aceder à página
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="manClasses.php">Gerir Turmas</a>
        <a  href="manQuizz.php">Gerir Quizz</a>
        <a  class="active" href="userManPg.php">Gerir utilizadores</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>
    <h1>Criar novo Utilizador</h1>
    <form action='createUser.php' method='GET'>
        
        <input type='text' name='name' placeholder="Nome"/>
        <br><br>
        <input type='text' name='username' placeholder="Username"/>
        <br><br>
        <input type='password' name='password' placeholder="Password"/>
        <br><br>
        <label style="font-size: x-large;" for="userType">Tipo de utilizador:</label>
        <br>
        <select name="userType">
            <option value='1'>Administrador</option>
            <option value='2'>Professor</option>
        </select>
        <br><br>
        <input type='submit' value='Registar'/>
    </form>
</body>

</html>
<?php
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>