<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1 || $_SESSION['userType']==2)
	{
		$subject = $_GET['subject'];
		
		//verificar se algum dos campos do formulário está vazio
		//se sim, apresenta erro
		if (empty($subject))
		{
			echo '<script>alert("ERRO no registo! Verifique os dados inseridos!")</script>'; //cria um alerta popup
			echo '<script>window.location.href = "createSubjectPg.php"</script>'; //volta à página de registo
		}
		else 
		{
			//verificar se a pergunta já existe
			$res = "SELECT subject FROM subjects WHERE subject='".$subject."'";
			$verificaUtilizador = mysqli_query($conn, $res);
			$utilizadorExiste = mysqli_num_rows($verificaUtilizador);
		
			if ($utilizadorExiste)
			{
				echo '<script> alert("Esta pergunta já existe! Altere a pergunta.")</script>';
				echo '<script>window.location.href = "createQuestionPg.php"</script>';
			}
			else 
			{
				
				$query = "INSERT INTO subjects VALUES ('".$id."','".$subject."')";
				$resultado = mysqli_query($conn, $query);
		
				echo '<script> alert("Pergunta registada com sucesso!")</script>';
				echo '<script>window.location.href = "manQuizz.php"</script>';
			}
		}
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>