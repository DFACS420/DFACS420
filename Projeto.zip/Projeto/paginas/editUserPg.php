<?php
	ob_start();
	include "../basedados/basedados.h";
	session_start();
	
if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION["userType"]==1)
	{
		//se isto for verdade deixa aceder à página
		
		$username=$_GET['username'];
		$userType=$_GET['userType'];
?>
<html>

<head>
    <link rel="stylesheet" href="head.css">
</head>

<body>
    <div class="topnav">
        <a style="float:left" href="index.php">Framework</a>
        <a  href="logout.php">Logout</a>
        <a  href="personalDataPg.php">Os meus dados pessoais</a>
        <a  href="editDataPg.php">Gerir marcações</a>
        <a  class="active" href="userManPg.php">Gerir utilizadores</a>
        <a  href="userIndex.php">Início</a>
    </div>
    <br>

</html>
<?php			
				echo "<h1>Editar o utilizador: ".$username."</h1>
				<br>
			</body>
	</html>";

		$query = "SELECT * FROM users WHERE username = '".$username."'";
		$resultado = mysqli_query($conn, $query);
			
		if(! $resultado ){
			die('Could not get data: ' . mysqli_error($conn));// se não funcionar dá erro
		}
			
		//criar uma tabela com a visualização dos dados do utilizador
		echo "<table>";
		while($row = mysqli_fetch_array($resultado))
		{
			echo "<tr><td>Nome</td><td>".$row['name']."</td>";
			echo "<td><a href='editUser.php?username=".$username."&name=".$row['name']."'><input type=button value='Alterar' ></a></td></tr>";
			
			echo "<tr><td>username</td><td>".$row['username']."</td>";
			echo "<td><a href='editUser.php?username=".$username."'><input type=button value='Alterar' ></a></td></tr>";
			
			if ($row['userType']==1)
				echo "<tr><td>Tipo de Utilizador</td><td>Administrador</td>";
			else if ($row['userType']==2)
				echo "<tr><td>Tipo de Utilizador</td><td>Professor</td>";
			else 
			echo "<td><a href='editUser.php?username=".$username."&userType=".$row['userType']."'><input type=button value='Alterar' ></a></td></tr>";
			
			echo "</table><br><br>";
		}
	}
	else 
	{
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>