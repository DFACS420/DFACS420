<?php
	include "../basedados/basedados.h";
	session_start();
	
	if($_SESSION["login"] && isset($_SESSION["userType"]) && $_SESSION['userType']==1)
	{
		//se isto for verdade deixa aceder à página
?>
<html>
<head>
	<link rel="stylesheet" href="head.css">
	</head>
	<body>
		<div class="topnav">
		<a style="float:left" href="index.php">Framework</a>
			<a  href="logout.php">Logout</a>
			<a  href="personalDataPg.php">Os meus dados pessoais</a>
			<a  href="manClasses.php">Gerir Turmas</a>
			<a  href="manQuizz.php">Gerir Quizz</a>
			<a  class="active" href="userManPg.php">Gerir utilizadores</a>
			<a  href="userIndex.php">Início</a>
		</div>
		<br>
		<h1>Gerir utilizadores</h1>
		<br><br><br>
		
		<a href="createUserPg.php"/> <input type=button value='Criar novo utilizador' ></a>
		<br><br><br>
		<a href="viewUsersPg.php"/> <input type=button value='Visualizar utilizadores'></a>
		<br><br><br>
		
	</body>
</html>
<?php
	}
	else {
		//se for falso, redireciona para a página inicial do site
		echo '<script> alert("Não tem permissão para estar nesta página!")</script>';
		echo '<script>window.location.href = "index.php"</script>';
	}
?>