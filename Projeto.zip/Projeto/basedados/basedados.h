<?php
	define("HOST_BD", "localhost");
	define("USER_BD", "root");
	define("PASS_BD", "");
	define("NOME_BD", "framework");
	
	$conn = mysqli_connect(HOST_BD, USER_BD, PASS_BD);
	if (!$conn){
		die('Could not connect: ' . mysqli_error($conn));
	}
	mysqli_select_db($conn, NOME_BD);
?>